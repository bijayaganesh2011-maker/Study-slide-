# Study Slide starter website

This is a free, static starter website. Open `index.html` in a browser to preview it.

## What is included
- Dark black and neon-blue responsive design
- Home, Classes, Materials, Practice, About and Contact sections
- Class/college browsing, resource search and a sample MCQ

## Important limitations
This starter is a static website. It does not include Google sign-in, user accounts, paid memberships, payment processing, a private admin dashboard, or a database. The sample resources are placeholders, not real chapter PDFs. Do not collect student personal information through this demo.

## Add your own study files
1. Put your PDF files in the `materials` folder.
2. Edit `index.html` in a text editor.
3. Replace the sample resource entries in the `resources` array with your own class, subject, chapter and file details.
4. Add a link such as `materials/class-10-statistics.pdf` to the resource card.

## Publish free
You can host a static site with a free static hosting service such as GitHub Pages. You will need to create an account and upload the files. Hosting providers' terms and free-plan limits can change.
